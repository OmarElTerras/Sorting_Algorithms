package com.example.assignment1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;

import java.net.URL;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.ResourceBundle;

public class SortingHubController implements Initializable {

    private SortingStrategy SortingMethod;

    private int[] intArray;

    @FXML
    private Button btnReset;

    @FXML
    private Button btnSort;

    @FXML
    private ComboBox<String> cboSort;

    @FXML
    private Label lblNum;

    @FXML
    private Pane pane;

    @FXML
    private Slider slider;

    @FXML
    void action() {
        lblNum.setText(String.valueOf((int)slider.getValue()));
        int val = (int)slider.getValue();

        intArray= new int[val];

        LinkedHashSet<Integer> lhs = new LinkedHashSet<Integer>();
        int Min = 1;
        int Max = val +1;
        while(lhs.size() < val){
            int num = Min + (int)(Math.random() * ((Max - Min)));
            lhs.add(num);
        }

        Iterator<Integer> it = lhs.iterator();

        int counter = 0;
        while (it.hasNext()){
            intArray[counter] = it.next();
            counter++;
        }

        updateGraph(intArray);

    }
    public void updateGraph(int [] data){
        pane.getChildren().setAll();
        double x = 0.0;
        for (int i = 0; i < data.length; i++) {
            Rectangle r = new Rectangle(pane.getPrefWidth()/data.length-2,data[i]*pane.getPrefHeight()/((int)slider.getValue()) , Color.RED);
            r.relocate(x,0);
            x += pane.getPrefWidth()/data.length;
            pane.getChildren().add(r);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        cboSort.getItems().addAll("Merge Sort", "Selection Sort");
        cboSort.setValue("Merge Sort");
        slider.adjustValue(64);
        action();
    }

    @FXML
    public void setSortStrategy(){
        if (cboSort.getSelectionModel().getSelectedItem().equals("Merge Sort")){
            SortingMethod = new MergeSort(this);
            SortingMethod.sort(intArray);

        } else {
            SortingMethod = new SelectionSort(this);
            SortingMethod.sort(intArray);
        }

        Thread thread = new Thread(SortingMethod);
        thread.start();

    }

    @FXML
    void click(ActionEvent actionEvent) {

    }

    @FXML
    void onClick() {
        cboSort.setValue("Merge Sort");
        slider.adjustValue(64);
        action();
    }


}
