package com.example.assignment1;

import javafx.application.Platform;

import java.util.Arrays;

public class MergeSort implements SortingStrategy{
    private int[] intArray;
    private SortingHubController controller;


    public MergeSort(SortingHubController controller){
        this.controller = controller;
    }

    /* Function to merge the subarrays of a[] */
    public void merge(int nums[], int first, int mid, int last)
    {
        int second = mid + 1;

        // If the direct merge is already sorted
        if (nums[mid] <= nums[second]) {
            return;
        }

        // Two pointers to maintain start
        // of both arrays to merge
        while (first <= mid && second <= last) {

            // If element 1 is in right place
            if (nums[first] <= nums[second]) {
                first++;
            }
            else {
                int value = nums[second];
                int index = second;

                // Shift all the elements between element 1
                // element 2, right by 1.
                while (index != first) {
                    nums[index] = nums[index - 1];
                    index--;
                }
                nums[first] = value;

                    Platform.runLater(() -> {
                    controller.updateGraph(nums);
                });
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                // Update all the pointers
                first++;
                mid++;
                second++;
            }}
            }



    void mergeSort(int ints[], int beginning, int ending)
    {
        if (beginning < ending)
        {
            int mid = (beginning + ending) / 2;
            mergeSort(ints, beginning, mid);
            mergeSort(ints, mid + 1, ending);
            merge(ints, beginning, mid, ending);
        }
    }


    public void run(){
        mergeSort(intArray,0,intArray.length-1);

    }

    @Override
    public void sort(int[] numbers) {
        intArray = numbers;
    }
}

