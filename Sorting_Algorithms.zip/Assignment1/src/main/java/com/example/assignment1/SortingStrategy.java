package com.example.assignment1;

public interface SortingStrategy extends Runnable {
    void sort(int[] numbers);
}
